<form action="login.php" method="post">
  <div>
    <label for="username">Nom d'utilisateur :</label>
    <input type="text" id="username" name="username">
  </div>
  <div>
    <label for="password">Mot de passe :</label>
    <input type="password" id="password" name="password">
  </div>
  <div>
    <input type="submit" value="Se connecter">
  </div>
</form>