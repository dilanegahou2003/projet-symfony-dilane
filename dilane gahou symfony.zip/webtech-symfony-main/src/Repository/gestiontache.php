<table>
  <thead>
    <tr>
      <th>Nom de la tâche</th>
      <th>Date d'échéance</th>
      <th>Description</th>
      <th>Photo</th>
      <th>Statut</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    <!-- Code pour récupérer les tâches depuis la base de données et les afficher ici -->
    <?php
      $tasks = getTasksFromDatabase();
      foreach ($tasks as $task) {
    ?>
    <tr>
      <td><?php echo $task['task_name']; ?></td>
      <td><?php echo $task['due_date']; ?></td>
      <td><?php echo $task['description']; ?></td>
      <td><?php echo $task['photo']; ?></td>
      <td><?php echo $task['status']; ?></td>
      <td>
        <form action="update_task.php" method="post">
          <input type="hidden" name="task_id" value="<?php echo $task['id']; ?>">
          <input type="submit" value="Modifier">
        </form>
        <form action="delete_task.php" method="post">
          <input type="hidden" name="task_id" value="<?php echo $