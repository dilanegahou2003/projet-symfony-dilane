<!DOCTYPE html>
<html>
<head>
  <title>To-Do List</title>
</head>
<body>
  <h1>To-Do List</h1>
  <form action="index.php" method="post">
    <input type="text" name="task">
    <input type="submit" value="Add task">
  </form>
  <?php
    $tasks = array();
    if (isset($_POST['task'])) {
      array_push($tasks, $_POST['task']);
    }
  ?>
  <h2>Tasks:</h2>
  <ul>
    <?php foreach ($tasks as $task): ?>
      <li><?php echo $task; ?></li>
    <?php endforeach; ?>
  </ul>
</body>
</html>
