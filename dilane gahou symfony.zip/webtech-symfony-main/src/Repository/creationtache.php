<form action="create_task.php" method="post" enctype="multipart/form-data">
  <div>
    <label for="task_name">Nom de la tâche :</label>
    <input type="text" id="task_name" name="task_name">
  </div>
  <div>
    <label for="due_date">Date d'échéance :</label>
    <input type="date" id="due_date" name="due_date">
  </div>
  <div>
    <label for="description">Description :</label>
    <textarea id="description" name="description"></textarea>
  </div>
  <div>
    <label for="photo">Photo :</label>
    <input type="file" id="photo" name="photo">
  </div>
  <div>
    <label for="status">Statut :</label>
    <select id="status" name="status">
      <option value="to_do">À faire</option>
      <option value="in_progress">En cours</option>
      <option value="done">Terminé</option>
    </select>
  </div>
  <div>
    <input type="submit" value="Créer tâche">
  </div>
</form>
